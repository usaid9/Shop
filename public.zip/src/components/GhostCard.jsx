/**
 * GhostCard — themed skeleton loader with shimmer wave
 * Matches ProductCard dimensions exactly so layout doesn't shift when content loads.
 */

function Shimmer() {
  return (
    <span
      aria-hidden="true"
      className="absolute inset-0 z-10"
      style={{
        background:
          'linear-gradient(90deg, transparent 0%, var(--ghost-shine) 50%, transparent 100%)',
        backgroundSize: '200% 100%',
        animation: 'ghost-sweep 1.6s ease-in-out infinite',
      }}
    />
  )
}

function GhostBlock({ className = '', style = {} }) {
  return (
    <span
      className={`relative block overflow-hidden rounded ${className}`}
      style={{ background: 'var(--ghost-base)', ...style }}
    >
      <Shimmer />
    </span>
  )
}

/** Grid ghost card — matches ProductCard grid layout */
export function GhostCard() {
  return (
    <div
      className="rounded-xl overflow-hidden"
      style={{
        background: 'var(--ghost-base)',
        border: '1px solid var(--border-subtle)',
      }}
    >
      {/* Image area */}
      <div className="relative overflow-hidden" style={{ aspectRatio: '3/4' }}>
        <GhostBlock className="absolute inset-0 rounded-none" />
      </div>
      {/* Info area */}
      <div
        className="p-3.5 space-y-2.5"
        style={{ background: 'var(--ghost-panel)' }}
      >
        <GhostBlock style={{ height: 10, width: '55%' }} />
        <GhostBlock style={{ height: 14, width: '85%' }} />
        <div className="flex items-center gap-1 pt-0.5">
          {[...Array(5)].map((_, i) => (
            <GhostBlock key={i} style={{ width: 10, height: 10, borderRadius: '50%' }} />
          ))}
          <GhostBlock style={{ height: 10, width: 28, marginLeft: 4 }} />
        </div>
        <GhostBlock style={{ height: 16, width: '40%' }} />
      </div>
    </div>
  )
}

/** List ghost card — matches ProductCard list layout */
export function GhostCardList() {
  return (
    <div
      className="flex gap-4 p-4 rounded-xl"
      style={{
        background: 'var(--ghost-base)',
        border: '1px solid var(--border-subtle)',
      }}
    >
      <GhostBlock style={{ width: 72, height: 80, borderRadius: 8, flexShrink: 0 }} />
      <div className="flex-1 space-y-2 py-1">
        <GhostBlock style={{ height: 10, width: '40%' }} />
        <GhostBlock style={{ height: 14, width: '80%' }} />
        <div className="flex gap-1">
          {[...Array(5)].map((_, i) => (
            <GhostBlock key={i} style={{ width: 10, height: 10, borderRadius: '50%' }} />
          ))}
        </div>
        <GhostBlock style={{ height: 16, width: '35%' }} />
      </div>
    </div>
  )
}

/** Full-page product detail ghost */
export function GhostProductDetail() {
  return (
    <div className="pt-[68px] min-h-screen px-4 sm:px-6 lg:px-8 py-12">
      <div className="max-w-6xl mx-auto">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 mb-8">
          {[60, 8, 80, 8, 120].map((w, i) =>
            i % 2 === 1
              ? <span key={i} className="text-muted opacity-40">/</span>
              : <GhostBlock key={i} style={{ height: 12, width: w }} />
          )}
        </div>
        <div className="grid md:grid-cols-2 gap-10">
          {/* Image */}
          <GhostBlock
            style={{ aspectRatio: '3/4', borderRadius: 16 }}
          />
          {/* Details */}
          <div className="space-y-5 pt-2">
            <GhostBlock style={{ height: 11, width: '35%' }} />
            <GhostBlock style={{ height: 44, width: '80%' }} />
            <GhostBlock style={{ height: 36, width: '30%' }} />
            <div className="space-y-2">
              <GhostBlock style={{ height: 12, width: '100%' }} />
              <GhostBlock style={{ height: 12, width: '90%' }} />
              <GhostBlock style={{ height: 12, width: '70%' }} />
            </div>
            <div>
              <GhostBlock style={{ height: 10, width: '15%', marginBottom: 10 }} />
              <div className="flex gap-2">
                {[1,2,3,4].map(i => <GhostBlock key={i} style={{ height: 38, width: 52, borderRadius: 10 }} />)}
              </div>
            </div>
            <div>
              <GhostBlock style={{ height: 10, width: '18%', marginBottom: 10 }} />
              <div className="flex gap-2">
                {[1,2,3].map(i => <GhostBlock key={i} style={{ height: 38, width: 64, borderRadius: 10 }} />)}
              </div>
            </div>
            <GhostBlock style={{ height: 52, width: '100%', borderRadius: 12 }} />
          </div>
        </div>
      </div>
    </div>
  )
}

/** Ghost grid — n cards in a responsive grid */
export function GhostGrid({ count = 8, cols = 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4' }) {
  return (
    <div className={`grid ${cols} gap-4 sm:gap-6`}>
      {Array.from({ length: count }).map((_, i) => (
        <GhostCard key={i} />
      ))}
    </div>
  )
}

export default GhostCard
